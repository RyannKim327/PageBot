### Extra Hints:

1. Know more about what is Metadata
2. Try to figure out how to solve a jigsaw puzzle.
3. You may restore a divided one, once you add it.
4. The filenames are intentionally shuffled.

Good luck
